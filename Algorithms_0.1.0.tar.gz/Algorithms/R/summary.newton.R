summary.newton <- function(a){

  print("function:")
  print(a[[1]])

  print("root:")
  print(newton(a[[1]],a[[2]]))
}
