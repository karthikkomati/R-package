print.newton_optimization_hd <- function(a){

  if(length(a)>= 3){
    print(newton_optimization_hd(a[[1]],a[[2]],a[[3]]))
  }else{
    print(newton_optimization_hd(a[[1]],a[[2]],a[[3]]))
  }
}
