plot.newton_optimization <- function(a){
  plot(a[[1]])
}
