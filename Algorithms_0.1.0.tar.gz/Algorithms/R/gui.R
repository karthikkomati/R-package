ui <- fluidPage(
  selectInput("method", label = "method", choices = list('gss','brent','newton')),
  verbatimTextOutput("summary"),
  tableOutput("table"),
  selectInput("func", label = "func", choices = list('x^2-2x-3','x^3+4x-5','x^2')),
  plotOutput("Graph"),
  verbatimTextOutput("points"),

)

server <- function(input, output, session) {

  output$Graph <- renderPlot(#expression(x^2),width = "auto",
                             #height = "auto",
    #plot(expression(x^2),1,3)
    if(input$func=='x^2'){
    curve(x^2, from=-5, to=5, , xlab="x", ylab="y")},
    #f3<- function(x){x^2-2*x-3},
    #plot(f3,-5,5)
                             )

  output$points<- renderPrint(
    print(1)

  )
}



shinyApp(ui, server)
