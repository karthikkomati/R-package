print.newton <-function(a){

  print(newton(a[[1]],a[[2]]))
}
