plot.newton_deriv <- function(a){
  plot(a[[1]])
}
