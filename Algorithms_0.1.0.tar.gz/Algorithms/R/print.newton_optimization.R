print.newton_optimization <- function(a){
  print(newton_optimization(a[[1]],a[[2]]))
}
