plot.gss <- function(a){
  plot(a[[1]],a[[2]],a[[3]])
}
