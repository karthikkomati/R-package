print.newton_deriv <- function(a){

  print(newton_deriv(a[[1]],a[[2]],a[[3]]))
}
