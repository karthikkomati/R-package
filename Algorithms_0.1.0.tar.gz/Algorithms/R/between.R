between = function(a,b,c){
  if(a<=b&a>=c){
    return(TRUE)
  }
  else if(a>=b&a<=c){
    return(TRUE)
  }
  else{
    return(FALSE)
  }

}
